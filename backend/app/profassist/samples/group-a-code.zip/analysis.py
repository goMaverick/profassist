BASELINE_KWH = 42.7
print('campus energy', BASELINE_KWH)
